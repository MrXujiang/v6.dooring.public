(window.webpackJsonp=window.webpackJsonp||[]).push([[35],{"00e+":function(l,e,t){"use strict";t.r(e);var O=t("XCrF"),E=t("1GRj"),i=t("q1tI"),n=t.n(i),o=Object(i.memo)(a=>{var c=a.width,d=a.height,h=a.opacity,s=a.src;return console.log(s),n.a.createElement(E.a,{style:{opacity:h},preview:!1,width:c,height:d,src:s,alt:"image"})});e.default=o}}]);

//# sourceMappingURL=35.js.map